<?php
	$id = $_POST['id'];
	$client = new SoapClient(......);

	if($_POST['Submit']=="Find"){
		$xml = ......;
		if($xml!=''){
			print $xml->cID."<br>";
			print $xml->cName."<br>";
			print $xml->cTel."<br>";
		}
		else
			print "No data";
	}
	if($_POST['Submit']=="Show All"){
		$result = ......;
		$xml = simplexml_load_string($result);
		foreach($xml->children() as $child)
		{
		echo $child->getName() . ": " . $child. "<br>";
		foreach($child->children() as $element)
		{
			echo $element->getName() . ": " . $element. "<br>";
		}
		}

	}	
?>