<?php
	// Use File Customer.xml
	function findXML($para){
		$xml = simplexml_load_file(......);
		foreach(......)
		{
			foreach(......)
			{
				if(......)
					return ......;
			}
		}
		return "";
	}
	function requestXML(){
		$xmlObject=simplexml_load_file(......);
		$xml = new DOMDocument();
		$xml->formatOutput = true;
		$xml->preserveWhiteSpace = false;
		$xml->loadXML($xmlObject->asXML()) or die("Error");
		return $xml->saveXML();

	}
    
    $server = new SoapServer(......);
	......
    
    $server->handle();    
?>