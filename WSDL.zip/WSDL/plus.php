<?php
	$number1=$_POST['number1'];
	$number2=$_POST['number2'];
  	$client = new SoapClient("plus.wsdl");
  	$result = $client->plus($number1,$number2);
  	echo $number1."+".$number2."=".$result;
?>