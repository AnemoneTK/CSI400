<?php

    function plus($num3,$num4) {
    	 
    	return $num3+$num4; 
   
    }
    
    $server = new SoapServer("plus.wsdl");
    
    $server->addFunction("plus");
    
    $server->handle();
    
?>